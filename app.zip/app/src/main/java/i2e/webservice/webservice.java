package i2e.webservice;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;

import com.example.mobilehealthcareworkspace.SingleInstances.ApplicationSingleInstances;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;


public class webservice {
	private static final int TIMEOUT_MILLISEC = 0;
	static String result = "";
	static InputStream is;
	static String contentAsString;
	static ArrayList<HashMap<String, String>> feedArrayList=new ArrayList<HashMap<String,String>>();

	public static String calllogin(String username,String password)
	{
		String myurl="http://192.168.0.28:8080/RestWebservice/REST/WebService/login?username="+username+"&password="+password;
	    /*HttpPost postMethod = new HttpPost("http://192.168.0.28:8080/RestWebservice/REST/WebService/login?username="+username+"&password="+password);*/

		try {
			URL url = new URL(myurl);
			HttpURLConnection conn=(HttpURLConnection)url.openConnection();
			conn.setReadTimeout(10000 /* milliseconds */);
			conn.setConnectTimeout(15000 /* milliseconds */);
			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			// Starts the query
			conn.connect();

			int response = conn.getResponseCode();
			is = conn.getInputStream();

			// Convert the InputStream into a string
			contentAsString = convertStreamToString(is);
			//return contentAsString;
		}
		catch (Exception e){
			e.printStackTrace();
		}

	/*    DefaultHttpClient hc = new DefaultHttpClient();

	    HttpResponse response = null;
		try {
			response = hc.execute(postMethod);
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    HttpEntity entity = response.getEntity();

	    if (entity != null) 
	    {
	            InputStream inStream = null;
				try {
					inStream = entity.getContent();
				} catch (IllegalStateException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	            result= convertStreamToString(inStream);
	            Log.i("---------------- Result",result);
	    }*/
		return contentAsString;
	} // end callWebService()

	public static String convertStreamToString(InputStream is)
	{

		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();

		String line = null;
		try
		{
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				is.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return sb.toString();
	}


	@SuppressLint("NewApi")
	public static ArrayList<HashMap<String,String>> getAppointment(String person_id,String Date) throws IOException
	{
		JSONArray JSONArrays=null;
		ArrayList<HashMap<String,String>> appointementList=new ArrayList<HashMap<String,String>>();
		//int currentDateandTime =MethodCollection.convertString2IntDate(date);
		String myurl="http://192.168.0.28:8080/RestWebservice/REST/WebService/Appointment?personid="+person_id.trim()+"&date="+Date;
	    /*HttpPost postMethod = new HttpPost("http://192.168.0.28:8080/RestWebservice/REST/WebService/login?username="+username+"&password="+password);*/

		try {
			URL url = new URL(myurl);
			HttpURLConnection conn=(HttpURLConnection)url.openConnection();
			conn.setReadTimeout(10000 /* milliseconds */);
			conn.setConnectTimeout(15000 /* milliseconds */);
			conn.setRequestMethod("GET");
			conn.setDoInput(true);
			// Starts the query
			conn.connect();

			int response = conn.getResponseCode();
			is = conn.getInputStream();

			// Convert the InputStream into a string
			contentAsString = convertStreamToString(is);
			//return contentAsString;
		}
		catch (Exception e){
			e.printStackTrace();
		}



/*		 HttpPost postMethod = new HttpPost("http://192.168.0.28:8080/RestWebservice/REST/WebService/Appointment?personid="+person_id.trim()+"&date="+Date);
		
	    DefaultHttpClient hc = new DefaultHttpClient();
		HttpResponse response = null;
		try {
				response = hc.execute(postMethod);
			} 
		catch (ClientProtocolException e)
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		catch (IOException e)
		{
				// TODO Auto-generated catch block
				e.printStackTrace();
		}
		 HttpEntity entity = response.getEntity();
		 if (entity != null) 
		 	{
		            InputStream inStream = null;
					try
					{
						inStream = entity.getContent();
						 result= convertStreamToString(inStream);
					} 
					catch (IllegalStateException e)
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					} 
					catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}*/
		try {
			// JSONObject json = new JSONObject();
			JSONArrays = new JSONArray(contentAsString);
			for (int i = 0; i < JSONArrays.length(); i++) {

				JSONObject JOTweets = JSONArrays.getJSONObject(i);
				appointementList=addDataFromJsonobject(JOTweets);
			}

		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		Log.i("---------------- Result",JSONArrays.toString());


		return  appointementList;

	}

	private static ArrayList<HashMap<String,String>> addDataFromJsonobject(JSONObject elementJsonObject)
	{
		String nextFollowupDate="";
		String nextFollowupTime="";
		String person_id="";
		String treatment_id = "";
		String patientName="";

		try {

			nextFollowupDate = elementJsonObject.getString("nextFollowupDate");

			//System.out.println("chkaddfromjsonPosturl->" + nextFollowupDate);
			nextFollowupTime = elementJsonObject.getString("nextFollowupTime");
			person_id=elementJsonObject.getString("person_id");
			treatment_id = elementJsonObject.getString("treatment_id");
			patientName = elementJsonObject.getString("firstname")+" "+elementJsonObject.getString("lastname");

		} catch (JSONException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		finally {
			HashMap<String, String> feedHashMap = new HashMap<String, String>();

			feedHashMap.put("nextFollowupDate", nextFollowupDate);
			feedHashMap.put("nextFollowupTime", nextFollowupTime);
			feedHashMap.put("person_id", person_id);
			feedHashMap.put("treatement_id",treatment_id);
			feedHashMap.put("patientName", patientName);
			System.out.println("feedHashMap"+feedHashMap);

			feedArrayList.add(feedHashMap);
			System.out.println("feedArrayList"+feedArrayList);
		}
		return feedArrayList;

	}
	@SuppressLint("NewApi")
	public void getPatientList(String person_id,Context context) throws IOException
	{
		JSONArray JSONArrays=null;
		ArrayList<HashMap<String,String>> patientList=new ArrayList<HashMap<String,String>>();
		//int currentDateandTime =MethodCollection.convertString2IntDate(date);
		Log.d("webservice",person_id);

		String myurl="http://192.168.0.28:8080/RestWebservice/REST/WebService/personalDetails?personid="+person_id.trim();
	    /*HttpPost postMethod = new HttpPost("http://192.168.0.28:8080/RestWebservice/REST/WebService/login?username="+username+"&password="+password);*/

		try {
			URL url = new URL(myurl);
			HttpURLConnection conn=(HttpURLConnection)url.openConnection();
			conn.setReadTimeout(10000 /* milliseconds */);
			conn.setConnectTimeout(15000 /* milliseconds */);
			conn.setRequestMethod("POST");
			conn.setDoInput(true);
			// Starts the query
			conn.connect();

			int response = conn.getResponseCode();
			is = conn.getInputStream();

			// Convert the InputStream into a string
			contentAsString = convertStreamToString(is);
			ApplicationSingleInstances instances=new ApplicationSingleInstances();
			instances.insertPatientData(contentAsString,context);
			//return contentAsString;
		}
		catch (Exception e){
			e.printStackTrace();
		}

	}
	private static ArrayList<HashMap<String,String>> addDataFromJsonobject1(JSONObject elementJsonObject)
	{
		//String fname="";
		//String lna="";
		String person_id="";
		//String treatment_id = "";
		String patientName="";

		try {

			//nextFollowupDate = elementJsonObject.getString("nextFollowupDate");

			//System.out.println("chkaddfromjsonPosturl->" + nextFollowupDate);
			//nextFollowupTime = elementJsonObject.getString("nextFollowupTime");
			person_id=elementJsonObject.getString("person_id");
			//treatment_id=elementJsonObject.getString("treatment_id");
			patientName=elementJsonObject.getString("firstname")+" "+elementJsonObject.getString("lastname");

		} catch (JSONException e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		finally {
			HashMap<String, String> feedHashMap = new HashMap<String, String>();

			//feedHashMap.put("nextFollowupDate", nextFollowupDate);
			//feedHashMap.put("nextFollowupTime", nextFollowupTime);
			feedHashMap.put("person_id", person_id);
			//feedHashMap.put("treatement_id",treatment_id);
			feedHashMap.put("patientName", patientName);
			System.out.println("feedHashMap"+feedHashMap);

			feedArrayList.add(feedHashMap);
			//System.out.println("feedArrayList"+feedArrayList);
		}
		return feedArrayList;

	}
}
