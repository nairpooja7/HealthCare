package com.example.mobilehealthcareworkspace;

import android.support.annotation.NonNull;

/**
 * @author jonatan.salas
 */
public interface DayDecorator {

    /**
     *
     * @param cell
     */
    void decorate(@NonNull DayView cell);
}