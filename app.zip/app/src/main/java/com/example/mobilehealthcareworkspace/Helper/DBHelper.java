package com.example.mobilehealthcareworkspace.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.mobilehealthcareworkspace.Beans.PatientDetailsBean;

import java.util.ArrayList;

/**
 * Created by siddhesh.rane on 3/11/2016.
 */
public class DBHelper extends SQLiteOpenHelper {


    /*..............Database string...............*/
    static final int DB_VERSION = 1;
    static final String DATABASE_NAME = "mHealth";

    static final String TABLE_PATIENT_DETAILS = "patient_details";



    /*........TABLES COLUMNS STRING...................*/
    static final String PATIENT_ID_COLUMN = "patient_id";
    static final String PATIENT_DISPLAY_NAME = "displayname";
    static final String PATIENT_FIRST_NAME  = "firstname";
    static final String PATIENT_MIDDLE_NAME = "middlename";
    static final String PATIENT_LAST_NAME = "lastname";
    static final String PATIENT_BIRTH_DATE = "birthdate";
    static final String PATIENT_GENDER = "gender";
    static final String PATIENT_EMAIL= "email";
    static final String PATIENT_MOBILE = "mobile";
    static final String PATIENT_PHONE = "phone";
    static final String PATIENT_HOSPITAL_ID = "hospital_id";
    static final String PATIENT_BLOOD_GROUP = "bloodgroup";
    static final String PATIENT_RH = "rh";
    static final String PATIENT_IS_SYNC = "is_sync";



    /*............. TABLE CREATION ................*/
    static final String CREATE_PATIENT_DETAILS = "CREATE TABLE "+ TABLE_PATIENT_DETAILS + "("
            + PATIENT_ID_COLUMN + " integer primary key,"
            + PATIENT_DISPLAY_NAME + " text,"
            + PATIENT_FIRST_NAME + " text,"
            + PATIENT_LAST_NAME + " text,"
            + PATIENT_MIDDLE_NAME + " text,"
            + PATIENT_BIRTH_DATE + " text,"
            + PATIENT_GENDER + " text,"
            + PATIENT_EMAIL + " text,"
            + PATIENT_MOBILE + " text,"
            + PATIENT_PHONE + " text,"
            + PATIENT_HOSPITAL_ID + " text,"
            + PATIENT_BLOOD_GROUP + " text,"
            + PATIENT_RH + " text,"
            + PATIENT_IS_SYNC + " text"
            + ")";


    /*...............TABLE DROP.....................*/
    static final String DROP_PATIENT_DETAILS = "DROP TABLE IF EXISTS "+ TABLE_PATIENT_DETAILS  ;

    /*...............Context String..................*/
    Context mContext;

    public DBHelper(Context mContext){
        super(mContext, DATABASE_NAME , null , DB_VERSION); //constructor for SQLITEOpenHelper
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(DROP_PATIENT_DETAILS);
        db.execSQL(CREATE_PATIENT_DETAILS);
    }

    public boolean insertPatientDetails  (ArrayList<PatientDetailsBean> patientList)
    {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues;


        for (int i=0;i<patientList.size();i++) {

            PatientDetailsBean patientDetailsBean = (PatientDetailsBean) patientList.get(i);
            contentValues = new ContentValues();
            contentValues.put(PATIENT_ID_COLUMN, patientDetailsBean.getPatient_id());
            contentValues.put(PATIENT_DISPLAY_NAME, patientDetailsBean.getDisplay_name());
            contentValues.put(PATIENT_FIRST_NAME, patientDetailsBean.getFirst_name());
            contentValues.put(PATIENT_LAST_NAME, patientDetailsBean.getLast_name());
            contentValues.put(PATIENT_MIDDLE_NAME, patientDetailsBean.getMiddle_name());
            contentValues.put(PATIENT_BIRTH_DATE, patientDetailsBean.getBirthdate());
            contentValues.put(PATIENT_GENDER, patientDetailsBean.getGender());
            contentValues.put(PATIENT_EMAIL, patientDetailsBean.getEmail());
            contentValues.put(PATIENT_MOBILE, patientDetailsBean.getMobile());
            contentValues.put(PATIENT_PHONE, patientDetailsBean.getPhone());
            contentValues.put(PATIENT_HOSPITAL_ID, patientDetailsBean.getHospital_id());
            contentValues.put(PATIENT_BLOOD_GROUP, patientDetailsBean.getBlood_group());
            contentValues.put(PATIENT_RH, patientDetailsBean.getPatient_rh());
            contentValues.put(PATIENT_IS_SYNC, patientDetailsBean.getIs_sync());

            db.insert(TABLE_PATIENT_DETAILS, null , contentValues);


        }
        db.close();

        return true;
    }

    public ArrayList<PatientDetailsBean> getPatientList(){
        ArrayList<PatientDetailsBean> tempPatientList = new ArrayList<PatientDetailsBean>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from " +TABLE_PATIENT_DETAILS, null );

        if (res.moveToFirst()) {
            do {
                // get  the  data into array,or class variable
                PatientDetailsBean patientDetailsBean=new PatientDetailsBean();
                patientDetailsBean.setPatient_id(res.getString(res.getColumnIndex(PATIENT_ID_COLUMN)));
                //patientDetailsBean.setDisplay_name(res.getString(res.getColumnIndex(PATIENT_DISPLAY_NAME)));
                patientDetailsBean.setFirst_name(res.getString(res.getColumnIndex(PATIENT_FIRST_NAME)));
                patientDetailsBean.setLast_name(res.getString(res.getColumnIndex(PATIENT_LAST_NAME)));
                patientDetailsBean.setMiddle_name(res.getString(res.getColumnIndex(PATIENT_MIDDLE_NAME)));
                patientDetailsBean.setBirthdate(res.getString(res.getColumnIndex(PATIENT_BIRTH_DATE)));
                patientDetailsBean.setGender(res.getString(res.getColumnIndex(PATIENT_GENDER)));
                //patientDetailsBean.setEmail(res.getString(res.getColumnIndex(PATIENT_EMAIL)));
                patientDetailsBean.setMobile(res.getString(res.getColumnIndex(PATIENT_MOBILE)));
                //patientDetailsBean.setPhone(res.getString(res.getColumnIndex(PATIENT_PHONE)));
                patientDetailsBean.setHospital_id(res.getString(res.getColumnIndex(PATIENT_HOSPITAL_ID)));
                patientDetailsBean.setBlood_group(res.getString(res.getColumnIndex(PATIENT_BLOOD_GROUP)));
                patientDetailsBean.setPatient_rh(res.getString(res.getColumnIndex(PATIENT_RH)));
                patientDetailsBean.setIs_sync(res.getString(res.getColumnIndex(PATIENT_IS_SYNC)));
                tempPatientList.add(patientDetailsBean);
            } while (res.moveToNext());
        }
        return tempPatientList;
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        dropTable(db); //Drop all tables
        onCreate(db); //create all Tables
    }

    /*...............Function to drop all tables..........*/
    public void dropTable(SQLiteDatabase db){
        db.execSQL(DROP_PATIENT_DETAILS);
    }

}
