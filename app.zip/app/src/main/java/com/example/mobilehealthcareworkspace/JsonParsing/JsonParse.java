package com.example.mobilehealthcareworkspace.JsonParsing;

import android.content.Context;

import com.example.mobilehealthcareworkspace.Beans.PatientDetailsBean;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by siddhesh.rane on 3/18/2016.
 */
public class JsonParse {

    JSONArray jsonArray;
    String jsonString;
    Context context;

    public JsonParse(String jsonString,Context context){
        this.jsonString = jsonString;
        this.context = context;
    }

    public ArrayList<PatientDetailsBean> parsePatientList(){
        ArrayList<PatientDetailsBean> patientDetail=new ArrayList<PatientDetailsBean>();
        try {
            jsonArray = new JSONArray(jsonString);

            if(jsonArray.length()>0){
                for(int i=0;i<jsonArray.length();i++){
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    PatientDetailsBean patientDetailsBean = new PatientDetailsBean();
                    patientDetailsBean.setPatient_id(jsonObject.getString("person_id"));
                    //patientDetailsBean.setDisplay_name(jsonObject.getString("displayname"));
                    patientDetailsBean.setFirst_name(jsonObject.getString("firstname"));
                    patientDetailsBean.setLast_name(jsonObject.getString("lastname"));
                    patientDetailsBean.setMiddle_name(jsonObject.getString("middlename"));
                    patientDetailsBean.setBirthdate(jsonObject.getString("birthdate"));
                    patientDetailsBean.setGender(jsonObject.getString("gender"));
                   // patientDetailsBean.setEmail(jsonObject.getString("email"));
                    patientDetailsBean.setMobile(jsonObject.getString("mobile"));
                    //patientDetailsBean.setPhone(jsonObject.getString("phone"));
                    patientDetailsBean.setHospital_id(jsonObject.getString("hospital_id"));
                    patientDetailsBean.setBlood_group(jsonObject.getString("bloodgroup"));
                    patientDetailsBean.setPatient_rh(jsonObject.getString("rh"));
                    patientDetailsBean.setIs_sync("1");
                    patientDetail.add(patientDetailsBean);

                }

            }
        }catch (JSONException e){
            e.printStackTrace();
        }

        return patientDetail;
    }

}
