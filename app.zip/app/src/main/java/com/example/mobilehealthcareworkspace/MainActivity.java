package com.example.mobilehealthcareworkspace;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.IOException;

import i2e.webservice.webservice;

public class MainActivity extends AppCompatActivity {

    EditText password, userName;
    Button login;
    ProgressBar progressBar;
    /*    String URL = "http://192.168.0.28:8080/RestWebservice/REST/WebService/login";
        String result = "";*/
    String person_id = null;
    String str_getName, str_getPass;
    String s1, s2;
    SharedPreferences.Editor editor;
    SharedPreferences sh;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        password = (EditText) findViewById(R.id.et_password);
        userName = (EditText) findViewById(R.id.et_username);
        login = (Button) findViewById(R.id.btn_login);

        /* fetching the data from shared preference in order to make user login */
		/* data are saved in application through SplashActivity */
		/* only name and password is sufficient to make login */
        str_getName = SplashScreenActivity.sh.getString("name", null);
        str_getPass = SplashScreenActivity.sh.getString("password", null);

        progressBar = (ProgressBar) findViewById(R.id.progressBar1);
        progressBar.setVisibility(View.GONE);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

        StrictMode.setThreadPolicy(policy);

        login.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);

                s1 = userName.getText().toString();
                s2 = password.getText().toString();

                System.out.println("s1 is " + s1);
                Log.d("Are you in...", "");
                person_id = webservice.calllogin(s1, s2);
                Log.d("MainActivity", " " + person_id);
                if (person_id != "" && s1.length() > 0 && s2.length() > 0) {


                    /*progressBar.setVisibility(View.INVISIBLE);
                    //Toast.makeText(getApplicationContext(), "Login Successfully as person_id : " + person_id, Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    intent.putExtra("person_id", person_id);
                    startActivity(intent);*/
                    getPatientAsync async = new getPatientAsync();
                    async.execute();


                } else {
                    Toast.makeText(getApplicationContext(), "Login Not Successful", Toast.LENGTH_LONG).show();
                    progressBar.setVisibility(View.INVISIBLE);
                }
            }
        });


    }

    public class getPatientAsync extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            Log.d("MainActivity", "Inside Aynctask");
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {

            if (!person_id.equals(null) || !person_id.contains("sorry")) {
                System.out.println("you are in login page" + person_id);
                try {

                    webservice service = new webservice();
                    service.getPatientList(person_id, getApplicationContext());
                    SplashScreenActivity.editor.putString("loginTest", "true");
                    SplashScreenActivity.editor.putString("userName", s1);
                    SplashScreenActivity.editor.putString("password",s2);

                    SplashScreenActivity.editor.commit();

                    /*Toast.makeText(getApplicationContext(),
                            "You have successfuly login", Toast.LENGTH_LONG).show();

                    Intent sendToHome = new Intent(getApplicationContext(),
                            HomeActivity.class);

                    startActivity(sendToHome);*/

                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                //addEvnet.AddEventToCalender(feedArrayList,MainActivity.this);

            }
            return "done";
        }

        @Override
        protected void onPostExecute(String result) {
            progressBar.setVisibility(View.INVISIBLE);
        /*    SplashScreenActivity.editor.putString("loginTest", "true");
            SplashScreenActivity.editor.commit();

            Toast.makeText(getApplicationContext(),
                    "You have successfuly login", Toast.LENGTH_LONG).show();

            Intent sendToHome = new Intent(getApplicationContext(),
                    HomeActivity.class);

            startActivity(sendToHome);*/
            Intent intent = new Intent(MainActivity.this, HomeActivity.class);
            intent.putExtra("person_id", person_id);
            startActivity(intent);
            finish();
        }


    }
    // on back key press exit the application.

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            Intent intent = new Intent(getApplicationContext(), SplashScreenActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            intent.putExtra("EXIT", true);
            startActivity(intent);
        }
        return super.onKeyDown(keyCode, event);
    }

}


