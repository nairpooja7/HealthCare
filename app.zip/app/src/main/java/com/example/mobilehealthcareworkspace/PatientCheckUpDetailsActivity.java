package com.example.mobilehealthcareworkspace;

import android.app.Dialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;

import com.example.mobilehealthcareworkspace.Beans.PatientDetailsBean;
import com.example.mobilehealthcareworkspace.SingleInstances.ApplicationSingleInstances;

import java.util.ArrayList;

public class PatientCheckUpDetailsActivity extends AppCompatActivity {

    RecyclerView mRecyclerView;
    RecyclerView.LayoutManager mLayoutManager;
    CheckUpAdapter checkUpAdapter;
    int patientId;
    ArrayList Patientlist=null;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_check_up_details);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        Bundle extras = getIntent().getExtras();
        patientId=Integer.parseInt(extras.getString("patientId"));
        Log.d("get patientId",""+patientId);
        Patientlist = new ArrayList<>();

        mRecyclerView = (RecyclerView) findViewById(R.id.recycler_view);
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(mLayoutManager);
        getPatientAsync  getSync = new getPatientAsync();
        getSync.execute();
        Log.i("inside the adapter", "................");



    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case android.R.id.home:
                finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public class CheckUpAdapter extends RecyclerView.Adapter<CheckUpAdapter.ViewHolder> {
        ArrayList<PatientDetailsBean> patientList;
        Context mContext;

        public CheckUpAdapter(Context mContext, ArrayList<PatientDetailsBean> patientList) {
            this.mContext = mContext;
            this.patientList=patientList;

        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
            View v = LayoutInflater.from(viewGroup.getContext())
                    .inflate(R.layout.check_up_recycler_item, viewGroup, false);
            ViewHolder viewHolder = new ViewHolder(v);
            return viewHolder;
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, final int position) {

            final PatientDetailsBean patientDetailsBean=patientList.get(position);

            holder.checkUpDate.setText(patientDetailsBean.getFirst_name().toString());
            holder.txtComplaint.setText(patientDetailsBean.getFirst_name().toString());
            holder.txtDiagnosis.setText(patientDetailsBean.getFirst_name().toString());
            holder.txtPrescription.setText(patientDetailsBean.getFirst_name().toString());


        }

        @Override
        public int getItemCount() {
            return patientList.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            public final TextView checkUpDate;
            public final TextView txtComplaint;
            public final TextView txtDiagnosis;
            public final TextView txtPrescription;
            public final ImageView imgArrowUp;
            public final ImageView imgArrowDown;
            RelativeLayout mRelativeLayout;
            RelativeLayout mRelativeLayoutHeader;


            public ViewHolder(View itemView) {
                super(itemView);
                checkUpDate = (TextView) itemView.findViewById(R.id.txt_date);
                txtComplaint = (TextView) itemView.findViewById(R.id.txt_complaint);
                txtDiagnosis = (TextView) itemView.findViewById(R.id.txt_diagnosis);
                txtPrescription = (TextView) itemView.findViewById(R.id.txt_prescription);
                imgArrowUp = (ImageView)itemView.findViewById(R.id.img_arrow_up);
                imgArrowDown = (ImageView)itemView.findViewById(R.id.img_arrow_down);
                mRelativeLayout = (RelativeLayout) itemView.findViewById(R.id.expandable);
                mRelativeLayout.setVisibility(View.GONE);
                mRelativeLayoutHeader = (RelativeLayout) itemView.findViewById(R.id.header);


                mRelativeLayoutHeader.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if(mRelativeLayout.isShown()){
                            PatientCheckUpAnimation.slide_up(mContext, mRelativeLayout);
                            mRelativeLayout.setVisibility(View.GONE);
                            imgArrowDown.setVisibility(View.GONE);
                            imgArrowUp.setVisibility(View.VISIBLE);
                        }
                        else{
                            mRelativeLayout.setVisibility(View.VISIBLE);
                            PatientCheckUpAnimation.slide_down(mContext, mRelativeLayout);
                            imgArrowUp.setVisibility(View.GONE);
                            imgArrowDown.setVisibility(View.VISIBLE);

                        }

                    }
                });


            }

        }
    }


    public class getPatientAsync extends AsyncTask<String,String,String> {

        @Override
        protected void onPreExecute(){
            Log.d("MainActivity", "Inside Aynctask");
        }

        @Override
        protected String doInBackground(String... params) {

            try
            {
                ApplicationSingleInstances singleInstances=new ApplicationSingleInstances();
                Patientlist = singleInstances.getPatientList(PatientCheckUpDetailsActivity.this);

            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

            return "done";
        }

        @Override
        protected void onPostExecute(String result){
            checkUpAdapter = new CheckUpAdapter(PatientCheckUpDetailsActivity.this, Patientlist);
            mRecyclerView.setAdapter(checkUpAdapter);
        }
    }


}
