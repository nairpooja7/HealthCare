package com.example.mobilehealthcareworkspace;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.ActionMode;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.amulyakhare.textdrawable.TextDrawable;
import com.amulyakhare.textdrawable.util.ColorGenerator;
import com.example.mobilehealthcareworkspace.Beans.PatientDetailsBean;
import com.example.mobilehealthcareworkspace.SingleInstances.ApplicationSingleInstances;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class PatientListFragment extends Fragment implements SearchView.OnQueryTextListener  {

    ProgressBar progressBar;
    RecyclerView mRecyclerView;
    PatientListRecyclerViewAdapter patientListRecyclerViewAdapter;
    ArrayList Patientlist=null;
    String person_id;
    SharedPreferences sh;
    Menu mMenu;
    CoordinatorLayout coordinatorLayout_patient_list;
    private ActionMode mActionMode;
    private static final int HIGHLIGHT_COLOR = 0x999be6ff;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view  = inflater.inflate(R.layout.fragment_patient_list, container, false);

        coordinatorLayout_patient_list = (CoordinatorLayout)view.findViewById(R.id.coordinatorLayout_patient_list);

        mRecyclerView = (RecyclerView)view.findViewById(R.id.recyclerview);

        setupRecyclerView(mRecyclerView);

        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.addItemDecoration(new DividerItemDecoration(getActivity(), DividerItemDecoration.VERTICAL_LIST));

        progressBar=(ProgressBar) view.findViewById(R.id.progressBar1);
        progressBar.setVisibility(View.GONE);
        Log.d("PatientListFragment", "PatientListFragment");


        sh= PreferenceManager.getDefaultSharedPreferences(getActivity());
        person_id = sh.getString(person_id,"person_id");

        if(Patientlist==null) {
            getPatientAsync getAsync = new getPatientAsync();
            getAsync.execute();
        }
        return view;

    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        setHasOptionsMenu(true);
        Patientlist = new ArrayList<>();

        patientListRecyclerViewAdapter = new PatientListRecyclerViewAdapter(getActivity(),Patientlist);
        mRecyclerView.setAdapter(patientListRecyclerViewAdapter);
    }
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.menu_home, menu);
        this.mMenu = menu;

        final MenuItem item = menu.findItem(R.id.action_search);

        final SearchView searchView = (SearchView) MenuItemCompat.getActionView(item);
        searchView.setMaxWidth(Integer.MAX_VALUE);
        searchView.setBackgroundResource(R.drawable.texfield_searchview_holo_light);

        searchView.setOnQueryTextListener(this);

        MenuItemCompat.setOnActionExpandListener(item,
                new MenuItemCompat.OnActionExpandListener() {
                    @Override
                    public boolean onMenuItemActionCollapse(MenuItem item) {
                        // Do something when collapsed
                        patientListRecyclerViewAdapter.setFilter(Patientlist);
                        return true; // Return true to collapse action view
                    }

                    @Override
                    public boolean onMenuItemActionExpand(MenuItem item) {
                        // Do something when expanded
                        return true; // Return true to expand action view
                    }
                });
    }


    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
    }


    @Override
    public boolean onQueryTextChange(String newText) {
        final List<PatientDetailsBean> filteredModelList = filter(Patientlist, newText);
        patientListRecyclerViewAdapter.setFilter(filteredModelList);
        return true;
    }

    @Override
    public boolean onQueryTextSubmit(String query) {
        return false;
    }

    private List<PatientDetailsBean> filter(List<PatientDetailsBean> models, String query) {
        query = query.toLowerCase();

        final List<PatientDetailsBean> filteredModelList = new ArrayList<>();
        for (PatientDetailsBean model : models) {
            final String text = model.getFirst_name().toLowerCase();
            if (text.contains(query)) {
                filteredModelList.add(model);
            }
        }
        return filteredModelList;
    }
    private void setupRecyclerView(RecyclerView recyclerView) {
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        //recyclerView.setAdapter(new SimpleStringRecyclerViewAdapter(getActivity(),Patientlist));
    }
    public class getPatientAsync extends AsyncTask<String,String,String> {

        @Override
        protected void onPreExecute(){
            Log.d("MainActivity", "Inside Aynctask");
            progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        protected String doInBackground(String... params) {

            if(!person_id.equals("")||!person_id.contains("sorry"))
            {
                System.out.println("you are in login page" + person_id);
                try
                {
                    ApplicationSingleInstances singleInstances=new ApplicationSingleInstances();
                    Patientlist = singleInstances.getPatientList(getActivity());

                } catch (Exception e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }

            }
            return "done";
        }

        @Override
        protected void onPostExecute(String result){
            progressBar.setVisibility(View.INVISIBLE);
            patientListRecyclerViewAdapter =new PatientListRecyclerViewAdapter(getActivity(),Patientlist);
            mRecyclerView.setAdapter(patientListRecyclerViewAdapter);
        }
    }

    //List item select method
    private void onListItemSelect(int position) {
        patientListRecyclerViewAdapter.toggleSelection(position);//Toggle the selection
        boolean hasCheckedItems = patientListRecyclerViewAdapter.getSelectedCount() > 0;//Check if any items are already selected or not
        if (hasCheckedItems && mActionMode == null)
            // there are some selected items, start the actionMode
            mActionMode = ((AppCompatActivity) getActivity()).startSupportActionMode(callback);
        else if (!hasCheckedItems && mActionMode != null)
            // there no selected items, finish the actionMode
            mActionMode.finish();
        if (mActionMode != null)
            //set action mode title on item selection
            mActionMode.setTitle(String.valueOf(patientListRecyclerViewAdapter
                    .getSelectedCount()) + " selected");
    }

    //Set action mode null after use
    public void setNullToActionMode() {
        if (mActionMode != null)
            mActionMode = null;
    }

    private ActionMode.Callback callback=new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu)
        {
            MenuInflater menuInflater=mode.getMenuInflater();
            menuInflater.inflate(R.menu.context_menu_patient_list,menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            mode.setTitle("1 item is selected");
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            if (item.getItemId()==R.id.action_delete)
            {

                Toast.makeText(getActivity(),"Do you really want to delete??",Toast.LENGTH_SHORT).show();
                /*patientListRecyclerViewAdapter.deleteRows();
                Snackbar snackbar = Snackbar
                        .make(coordinatorLayout_patient_list,"Item Added", Snackbar.LENGTH_LONG).setAction("UNDO", new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                //int adapterPosition = mRecyclerView.getChildAdapterPosition(view);

                                patientListRecyclerViewAdapter.addItems();
                                patientListRecyclerViewAdapter.notifyDataSetChanged();
                            }
                        });
                snackbar.setActionTextColor(Color.RED);
                View sbView = snackbar.getView();
                TextView textView = (TextView) sbView.findViewById(android.support.design.R.id.snackbar_text);
                textView.setTextColor(Color.YELLOW);
                snackbar.show();
                return true;*/
            }
            return false;
        }


        @Override
        public void onDestroyActionMode(ActionMode mode) {

            patientListRecyclerViewAdapter.removeSelection();
            if(getActivity()!=null) {
                setNullToActionMode();
            }

        }
    };

    public class PatientListRecyclerViewAdapter
            extends RecyclerView.Adapter<PatientListRecyclerViewAdapter.ViewHolder> {

        ArrayList<PatientDetailsBean> patientList = new ArrayList<PatientDetailsBean>();
        Context mContext;
        ColorGenerator mColorGenerator = ColorGenerator.MATERIAL;
        TextDrawable.IBuilder mDrawableBuilder = TextDrawable.builder().round();
        private SparseBooleanArray mSelectedItemsIds;


        public class ViewHolder extends RecyclerView.ViewHolder {

            public final LinearLayout recycler_view_item_layout;
            public final TextView patient_name;
            public final ImageView img_info;
            public final ImageView img_call;
            public final ImageView img_message;
            public final ImageView image_patient;
            public final ImageView check_icon;

            public ViewHolder(View view) {
                super(view);
                patient_name = (TextView) view.findViewById(R.id.txt_patient_name);
                img_info = (ImageView) view.findViewById(R.id.img_info);
                img_call = (ImageView) view.findViewById(R.id.img_call);
                img_message = (ImageView) view.findViewById(R.id.img_message);
                image_patient = (ImageView) view.findViewById(R.id.image_patient);
                check_icon = (ImageView) view.findViewById(R.id.check_icon);
                recycler_view_item_layout = (LinearLayout) view.findViewById(R.id.recycler_view_item_layout);
            }

            @Override
            public String toString() {
                return super.toString() + " '" + patient_name.getText();
            }
        }

        private void updateCheckedState(final ViewHolder holder, final PatientDetailsBean patientDetailsBean) {

            if (patientDetailsBean.isChecked) {
                TextDrawable drawable = mDrawableBuilder.build(String.valueOf(patientDetailsBean.getFirst_name().charAt(0)), mColorGenerator.getRandomColor());
                holder.image_patient.setImageDrawable(drawable);
                holder.recycler_view_item_layout.setBackgroundColor(HIGHLIGHT_COLOR);
                //holder.check_icon.setVisibility(View.VISIBLE);


            } else {
                TextDrawable drawable = mDrawableBuilder.build(String.valueOf(patientDetailsBean.getFirst_name().charAt(0)), mColorGenerator.getRandomColor());
                holder.image_patient.setImageDrawable(drawable);
                holder.recycler_view_item_layout.setBackgroundColor(Color.TRANSPARENT);
                //holder.check_icon.setVisibility(View.GONE);
            }

        }

        public PatientListRecyclerViewAdapter(Context mContext, ArrayList<PatientDetailsBean> patientList) {
            this.patientList = patientList;
            this.mContext = mContext;
            mSelectedItemsIds = new SparseBooleanArray();

        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.list_item, parent, false);
            return new ViewHolder(view);
        }

        @Override
        public void onBindViewHolder(final ViewHolder holder, final int position) {

            final PatientDetailsBean patientDetailsBean = patientList.get(position);
            if (patientDetailsBean.getFirst_name() != null) {
                holder.patient_name.setText(patientDetailsBean.getFirst_name().toString());

            }

            updateCheckedState(holder, patientDetailsBean);

            //holder.image_patient.setImageDrawable(drawable);
            holder.image_patient.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   /* // when the image is clicked, update the selected state
                    final PatientDetailsBean patientDataList = patientList.get(position);
                    patientDataList.setChecked(!patientDataList.isChecked);
                    updateCheckedState(holder, patientDataList);*/


                }


            });


            holder.recycler_view_item_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Context context = view.getContext();
                    Intent intent = new Intent(context, PatientCheckUpDetailsActivity.class);
                    intent.putExtra("patientId", patientDetailsBean.getPatient_id());
                    context.startActivity(intent);


                }

            });

            holder.itemView
                    .setBackgroundColor(mSelectedItemsIds.get(position) ? 0x9934B5E4
                            : Color.TRANSPARENT);


            holder.recycler_view_item_layout.setOnLongClickListener(new View.OnLongClickListener() {

                @Override
                public boolean onLongClick(View v) {
                    onListItemSelect(position);
                    final PatientDetailsBean patientDataList = patientList.get(position);
                    patientDataList.setChecked(!patientDataList.isChecked);
                    updateCheckedState(holder, patientDataList);
                    return true;
                }
            });

            holder.img_info.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                    LayoutInflater inflater = LayoutInflater.from(getActivity());
                    final View subView = inflater.inflate(R.layout.dialog_layout_patient_details_edit, null);


                    final AlertDialog alertDialog = builder.create();
                    alertDialog.setView(subView);
                    alertDialog.getWindow().setLayout(300, 400);

                    final TextView txtName = (TextView) subView.findViewById(R.id.txt_name_view);
                    txtName.setText(patientDetailsBean.getFirst_name().toString());
                    final TextView txtBloodGroup = (TextView) subView.findViewById(R.id.txt_blood_group_view);
                    txtBloodGroup.setText(patientDetailsBean.getBlood_group().toString());
                    final TextView txtAge = (TextView) subView.findViewById(R.id.txt_age_view);
                    txtAge.setText(patientDetailsBean.getBirthdate().toString());
                    final TextView txtGender = (TextView) subView.findViewById(R.id.txt_age_view);
                    txtGender.setText(patientDetailsBean.getGender().toString());

                    final TextView title = (TextView) subView.findViewById(R.id.dialog_title);
                    title.setText(R.string.view_patient_details_dialog_title);

                    final ImageView imgEdit = (ImageView) subView.findViewById(R.id.img_edit);
                    imgEdit.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            LinearLayout edit_layout = (LinearLayout) subView.findViewById(R.id.edit_layout);
                            edit_layout.setVisibility(View.VISIBLE);
                            TableLayout view_layout = (TableLayout) subView.findViewById(R.id.view_layout);
                            view_layout.setVisibility(View.GONE);
                            imgEdit.setVisibility(View.GONE);

                            title.setText(R.string.edt_patient_details_dialog_title);
                            final EditText edtName = (EditText) subView.findViewById(R.id.edt_name);
                            edtName.setText(patientDetailsBean.getFirst_name().toString());
                            final EditText edtBloodGroup = (EditText) subView.findViewById(R.id.edt_blood_group);
                            edtBloodGroup.setText(patientDetailsBean.getBlood_group().toString());
                            final EditText edtAge = (EditText) subView.findViewById(R.id.edt_age);
                            edtAge.setText(patientDetailsBean.getBirthdate().toString());
                            final EditText edtGender = (EditText) subView.findViewById(R.id.edt_gender);
                            edtGender.setText(patientDetailsBean.getGender().toString());
                            LinearLayout lnr_buttons = (LinearLayout) subView.findViewById(R.id.lnr_buttons);
                            lnr_buttons.setVisibility(View.VISIBLE);
                            Button btn_cancel = (Button) subView.findViewById(R.id.btn_cancel);
                            Button btn_save = (Button) subView.findViewById(R.id.btn_save);
                            btn_cancel.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    alertDialog.dismiss();
                                }
                            });
                            btn_save.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    alertDialog.dismiss();
                                }
                            });


                        }
                    });

                    alertDialog.show();
                }
            });

            holder.img_call.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Intent.ACTION_DIAL);
                    String p = "tel:" + getString(R.string.phone_number);
                    i.setData(Uri.parse(p));
                    startActivity(i);
                }
            });

            holder.img_message.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    PackageManager pm = getActivity().getPackageManager();
                    try {

                        Intent waIntent = new Intent(Intent.ACTION_SEND);
                        waIntent.setType("text/plain");
                        String text = "YOUR TEXT HERE";

                        PackageInfo info = pm.getPackageInfo("com.whatsapp", PackageManager.GET_META_DATA);
                        //Check if package exists or not. If not then code
                        //in catch block will be called
                        waIntent.setPackage("com.whatsapp");

                        waIntent.putExtra(Intent.EXTRA_TEXT, text);
                        startActivity(Intent.createChooser(waIntent, "Share with"));

                    } catch (PackageManager.NameNotFoundException e) {
                        Toast.makeText(getActivity(), "WhatsApp not Installed", Toast.LENGTH_SHORT)
                                .show();
                    }

                }
            });

        }

        public void addItems(){
            SparseBooleanArray selected = patientListRecyclerViewAdapter.getSelectedIds();
            //Loop all selected ids
            for (int i = selected.size(); i >= 0; i++) {
                if (selected.valueAt(i)) {
                    //If current id is selected add the item via key
                    Patientlist.add(selected.keyAt(i));
                    patientListRecyclerViewAdapter.notifyDataSetChanged();//notify adapter

                }
            }
            Toast.makeText(getActivity(), selected.size() + " item added", Toast.LENGTH_SHORT).show();

        }
        //Delete selected rows
        public void deleteRows() {
            SparseBooleanArray selected = patientListRecyclerViewAdapter
                    .getSelectedIds();//Get selected ids
            //Loop all selected ids
            for (int i = (selected.size() - 1); i >= 0; i--) {
                if (selected.valueAt(i)) {
                    //If current id is selected remove the item via key
                    Patientlist.remove(selected.keyAt(i));
                    patientListRecyclerViewAdapter.notifyDataSetChanged();//notify adapter

                }
            }
            Toast.makeText(getActivity(), selected.size() + " item deleted", Toast.LENGTH_SHORT).show();//Show Toast
            mActionMode.finish();//Finish action mode after use
        }


        //Toggle selection methods
        public void toggleSelection(int position) {
            selectView(position, !mSelectedItemsIds.get(position));
        }


        //Remove selected selections
        public void removeSelection() {
            mSelectedItemsIds = new SparseBooleanArray();
            notifyDataSetChanged();
        }


        //Put or delete selected position into SparseBooleanArray
        public void selectView(int position, boolean value) {
            if (value)
                mSelectedItemsIds.put(position, value);
            else
                mSelectedItemsIds.delete(position);

            notifyDataSetChanged();
        }

        //Get total selected count
        public int getSelectedCount() {
            return mSelectedItemsIds.size();
        }

        //Return all selected ids
        public SparseBooleanArray getSelectedIds() {
            return mSelectedItemsIds;
        }



        @Override
        public int getItemCount() {
            return patientList.size();
        }

        public void setFilter(List<PatientDetailsBean> patientDetailsBeans) {
            patientList = new ArrayList<>();
            patientList.addAll(patientDetailsBeans);
            notifyDataSetChanged();
        }

        @Override
        public void onAttachedToRecyclerView(RecyclerView recyclerView) {
            super.onAttachedToRecyclerView(recyclerView);
        }



    }

}
