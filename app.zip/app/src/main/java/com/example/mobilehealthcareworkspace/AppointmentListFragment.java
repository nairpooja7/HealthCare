package com.example.mobilehealthcareworkspace;


import android.graphics.RectF;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;



/**
 * A simple {@link Fragment} subclass.
 */
public class AppointmentListFragment extends Fragment {

    CalendarView calendarView;
    FloatingActionButton fab;
    CollapsingToolbarLayout collapsingToolbarLayout;


    public AppointmentListFragment() {

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_appointment_list, container, false);

        collapsingToolbarLayout = (CollapsingToolbarLayout)view.findViewById(R.id.app_bar);


        calendarView = (CalendarView) view.findViewById(R.id.calendar_view);
        fab = (FloatingActionButton)view.findViewById(R.id.fab);

        calendarView.setFirstDayOfWeek(Calendar.MONDAY);
        calendarView.setIsOverflowDateVisible(true);
        calendarView.setCurrentDay(new Date(System.currentTimeMillis()));
        calendarView.setBackButtonColor(R.color.colorAccent);
        calendarView.setNextButtonColor(R.color.colorAccent);
        calendarView.refreshCalendar(Calendar.getInstance(Locale.getDefault()));
        /*calendarView.setOnDateLongClickListener(new CalendarView.OnDateLongClickListener() {
            @Override
            public void onDateLongClick(@NonNull Date selectedDate) {
                SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault());
                textView.setText(df.format(selectedDate));
            }
        });*/


        /*calendarView.setOnMonthChangedListener(new CalendarView.OnMonthChangedListener() {
            @Override
            public void onMonthChanged(@NonNull Date monthDate) {
                SimpleDateFormat df = new SimpleDateFormat("dd MMMM yyyy", Locale.getDefault());
                if (actionBar != null )
                    actionBar.setTitle(df.format(monthDate));
            }
        });*/

        DayView dayView = calendarView.findViewByDate(new Date(System.currentTimeMillis()));
        if(dayView != null)
            Toast.makeText(getActivity(), "Today is: " + dayView.getText().toString() + "/" + calendarView.getCurrentMonth() + "/" +  calendarView.getCurrentYear(), Toast.LENGTH_SHORT).show();

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addAppointmentDialog();
            }
        });



        return view;
    }

    public void addAppointmentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        final View subView = inflater.inflate(R.layout.add_appointment_dialog, null);


        final AlertDialog alertDialog = builder.create();
        alertDialog.setView(subView);
        alertDialog.getWindow().setLayout(300, 400);

        final TextView title = (TextView) subView.findViewById(R.id.dialog_title);
        title.setText(R.string.add_appointment);


        final EditText edt_patient_name = (EditText) subView.findViewById(R.id.edt_patient_name);
        edt_patient_name.setText("");
        final EditText edt_appointment_date = (EditText) subView.findViewById(R.id.edt_appointment_date);
        edt_appointment_date.setText("");
        final EditText edt_appointment_time = (EditText) subView.findViewById(R.id.edt_appointment_time);
        edt_appointment_time.setText("");

        final Spinner spinner = (Spinner) subView.findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> spinner_adapter = ArrayAdapter.createFromResource(getActivity(), R.array.object_array, android.R.layout.simple_spinner_item);
        spinner.setAdapter(spinner_adapter);
// Used OnItemSelected Listener for Spinner item click, here i am showing a toast
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,int position, long id)
            {
                String selectedItem = spinner.getSelectedItem().toString();
                Toast.makeText(getContext(), "Clicked"+selectedItem, Toast.LENGTH_LONG).show();
// Toast is a message in android which apears for a small period of time and disapears
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent)
            {

            }
        });



        Button btn_cancel = (Button) subView.findViewById(R.id.btn_cancel);
        Button btn_save = (Button) subView.findViewById(R.id.btn_save);
        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        alertDialog.show();




    }





}
