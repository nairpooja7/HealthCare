package com.example.mobilehealthcareworkspace.SingleInstances;

import android.content.Context;
import android.util.Log;

import com.example.mobilehealthcareworkspace.Beans.PatientDetailsBean;
import com.example.mobilehealthcareworkspace.Helper.DBHelper;
import com.example.mobilehealthcareworkspace.JsonParsing.JsonParse;

import java.util.ArrayList;

/**
 * Created by siddhesh.rane on 3/18/2016.
 */
public class ApplicationSingleInstances {

    ArrayList<PatientDetailsBean> patientDetailsList;

    public ArrayList<PatientDetailsBean> getPatientDetailsList() {
        return patientDetailsList;
    }

    public void setPatientDetailsList(ArrayList<PatientDetailsBean> patientDetailsList,Context context) {
        DBHelper helper = new DBHelper(context);
        helper.insertPatientDetails(patientDetailsList);
    }

    public Boolean insertPatientData(String jsonData,Context context){
        JsonParse parse=new JsonParse(jsonData,context);
        this.patientDetailsList=parse.parsePatientList();
        DBHelper helper = new DBHelper(context);
        helper.insertPatientDetails(this.patientDetailsList);
        return true;

    }

    public ArrayList<PatientDetailsBean> getPatientList(Context context){
        DBHelper helper = new DBHelper(context);
        this.patientDetailsList = helper.getPatientList();
        Log.d("data ",""+this.patientDetailsList.get(0).getFirst_name());
        return this.patientDetailsList;

    }
}
